The files in this folder are .cap files.  
They are meant to be opened using Ethereal.  
Ethereal is an open source packet sniffer available at www.ethereal.com for free.  
In our experiments, we used Ethereal version .99.

1. Open the Ethereal .99
2. Go to "file" over the ethereal window and click it. 
3. After that click the "open",a window will pop up. 
4. You can browse to the desired file(unziped version of cases1.zip) through this window
   Note :- select Files of type: All files(*.*) in the pop up window.     
5. Double click on the case(any one of case1redone,case2,case3,case4).
6. Then the ethereal will be populated by that case.
7. As the test is concerned with sip clients,enter "sip" in the field "Field:" then press enter.
8. For Graph analysis:- Go to statistics->Flow Graph click on it.
9.Then a window will pop upby name Ethereal:Flow Graph
     select Displayed packets
            General flow
            Standard source/destinastion addresses
     and then click "ok"
10.Now you are able to see the Graph Analysis.
